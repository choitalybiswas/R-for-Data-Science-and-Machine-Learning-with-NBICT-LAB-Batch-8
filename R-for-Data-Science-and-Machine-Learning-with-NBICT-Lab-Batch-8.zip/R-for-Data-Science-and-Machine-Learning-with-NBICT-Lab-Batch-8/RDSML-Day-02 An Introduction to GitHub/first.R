# Updating the file
data = c(9, 6, 17, 31, 11)
x = mean(data)
summary(data)
z = x/2