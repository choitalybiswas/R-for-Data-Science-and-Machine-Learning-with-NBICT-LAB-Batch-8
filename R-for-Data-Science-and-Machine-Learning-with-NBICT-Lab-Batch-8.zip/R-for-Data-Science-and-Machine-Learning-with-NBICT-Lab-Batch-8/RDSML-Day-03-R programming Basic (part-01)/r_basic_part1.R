# Calculating some health parameter 
my_age = 97
my_weight = 60
my_height = 65 

x = (my_age*my_height)/my_weight
print(x)

students_height = c(50, 55, 64, 71, 45.25)
mean(students_height)
